<?php
namespace ism\controllers;

use ism\lib\AbstractController;
use ism\lib\Role;
use ism\lib\Session;
use ism\lib\Response;
use ism\models\ReservationModel;
use ism\lib\Request;
class ReservationController extends AbstractController {


    public function doReservation(Request $request){
        if(!isset($request->getParams()[0]) || !is_numeric($request->getParams()[0])){
            Response::redirectUrl("bien/showCatalogue");
        }
        $id_bien=$request->getParams()[0];
        Session::setSession("id_bien", $id_bien);
        Session::setSession("action", "reservation");
        if(Role::estClient()){
            Response::redirectUrl("reservation/addReservation");
        }elseif(!Role::estAdmin()){
            Response::redirectUrl("security/login");
        }

    }

    public function addReservation(){
        if(!Role::estClient())Response::redirectUrl("bien/showCatalogue");
        $id_client = Session::getSession("user_connect")["id"];
        $id_bien = Session::getSession("id_bien");
        Session::destroyKey("id_bien");
        Session::destroyKey("action");
        $model = new ReservationModel();
        $model->insert(["bien_id" => $id_bien, "client_id" => $id_client]);
        Response::redirectUrl("reservation/showReservationByClient/".$id_client);
    }

    public function showAllReservation(){}

    public function showReservationEnCours(){
        if(!Role::estAdmin())Response::redirectUrl("bien/showCatalogue");
        $model = new ReservationModel();
        $reservation = $model->selectReservationByEtat();
        $this->render("reservation/reservation",["reservations" => $reservation]);
    }

    public function showReservationByBien(){}

    public function showReservationByClient(Request $request){
        if(!isset($request->getParams()[0]) || !is_numeric($request->getParams()[0])){
            Response::redirectUrl("bien/showCatalogue");
        }
        if(!Role::estClient() && !Role::estAdmin())Response::redirectUrl("security/login");
        $idClient = $request->getParams()[0];
        $model = new ReservationModel();
        $data = $model->selectReservationByClient($idClient);
        $this->render("reservation/mes.reservation",["biens" => $data] );

    }



}