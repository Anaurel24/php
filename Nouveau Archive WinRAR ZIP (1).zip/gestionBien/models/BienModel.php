<?php
namespace ism\models;
use ism\lib\AbstractModel;
class BienModel extends AbstractModel{

    public function __construct() {
        parent::__construct();
        $this->tableName = "bien";
        $this->primaryKey = "id_bien";
    }

    public function selectAll():array {
        $sql="SELECT * FROM bien b,	propietaire p WHERE b.proprietaire_id=p.id_proprietaire ";
        $result=$this->selectBy($sql);
        return $result["data"];
    }
    
    public function selectById(int $id):array{
    
        $sql="SELECT * FROM bien b,	propietaire p WHERE b.proprietaire_id=p.id_proprietaire  AND b.id_bien=?";
        $result=$this->selectBy($sql,[$id],true);
        return $result["data"];
    }
}