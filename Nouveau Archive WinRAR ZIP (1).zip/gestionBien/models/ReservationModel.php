<?php
namespace ism\models;
use ism\lib\AbstractModel;
use ism\lib\FormatDate;

class ReservationModel extends AbstractModel {
    public const EN_COURS = "EN COURS";
    public const VALIDE = "VALIDE";
    public const ANNULER = "ANNULER";
    public function __construct() {
        parent::__construct();
        $this->tableName = "reservation";
        $this->primaryKey = "id_reservation";
    }



   public function selectReservationByClient(int $id_client){

        $sql= "SELECT * FROM reservation r, bien b, user u 
        WHERE r.bien_id=b.id_bien AND r.client_id =u.id AND r.client_id=?";
        $result=$this->selectBy($sql,[$id_client]);
        return $result["data"];
    }
    public function selectReservationByEtat(string $etat= self::EN_COURS){
        
        $sql= "SELECT * FROM reservation r, bien b, user u 
        WHERE r.bien_id=b.id_bien AND r.client_id =u.id AND r.etat=?";
        $result=$this->selectBy($sql,[$etat]);
        return $result["data"];
    }

    public function insert(array $reservation):bool{
        extract($reservation);
        $sql= "INSERT INTO reservation 
        (etat,create_at_reservation,bien_id,client_id)
        VALUES 
        (?,?,?,?)";
    
        $result=$this->persit($sql,[self::EN_COURS,FormatDate::createDateEn(),$bien_id,$client_id]);
        
        return $result["count"]==0?false:true;
    }

}